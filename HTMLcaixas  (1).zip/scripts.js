// scripts.js

document.addEventListener('DOMContentLoaded', function() {
      let currentSlide = 0;
      const slides = document.querySelectorAll('#banner .slide');
      const totalSlides = slides.length;

      function showSlide(index) {
  slides.forEach((slide, i) => {
    slide.classList.toggle('active', i === index);
  });
}

function nextSlide() {
  currentSlide = (currentSlide + 1) % totalSlides;
  showSlide(currentSlide);
}

setInterval(nextSlide, 3000); // Troca de slide a cada 3 segundos

// Funções de login e registro
const users = {}; // Armazena os usuários e senhas
const loginForm = document.getElementById('login-form');
const registerForm = document.getElementById('register-form');
const gameContainer = document.getElementById('game-container');

document.getElementById('show-register-form').addEventListener('click', function() {
  loginForm.style.display = 'none';
  registerForm.style.display = 'block';
});

document.getElementById('show-login-form').addEventListener('click', function() {
  registerForm.style.display = 'none';
  loginForm.style.display = 'block';
});

document.getElementById('register-button').addEventListener('click', function() {
  const username = document.getElementById('register-username').value.trim();
  const password = document.getElementById('register-password').value;

  if (username && password) {
    if (users[username]) {
      alert('Usuário já registrado.');
    } else {
      users[username] = password;
      alert('Registro bem-sucedido. Faça login.');
      registerForm.style.display = 'none';
      loginForm.style.display = 'block';
    }
  } else {
    alert('Por favor, preencha todos os campos.');
  }
});

document.getElementById('login-button').addEventListener('click', function() {
  const username = document.getElementById('login-username').value.trim();
  const password = document.getElementById('login-password').value;

  if (username && password) {
    if (users[username] === password) {
      loginForm.style.display = 'none';
      gameContainer.style.display = 'block';
      initializeTable();
    } else {
      alert('Usuário ou senha incorretos.');
    }
  } else {
    alert('Por favor, preencha todos os campos.');
  }
});

// Jogo
let currentRound = 1;
let blackColorApplied = false;
let selectedNumbers = [];

function initializeTable() {
  const tableBody = document.querySelector('tbody');
  let number = 1;
  tableBody.innerHTML = ''; // Limpa o conteúdo atual do corpo da tabela
  for (let i = 0; i < 5; i++) {
    const row = document.createElement('tr');
    for (let j = 0; j < 5; j++) {
      const cell = document.createElement('td');
      cell.innerHTML = `${number}<div class="corner-value">0</div>`;
      cell.dataset.number = number;
      cell.dataset.value = 0;
      row.appendChild(cell);
      number++;
    }
    tableBody.appendChild(row);
  }
}

function getRandomIndexes(count, max) {
  const indexes = [];
  while (indexes.length < count) {
    const rand = Math.floor(Math.random() * max);
    if (!indexes.includes(rand)) indexes.push(rand);
  }
  return indexes;
}

function applyColors() {
  const cells = Array.from(document.querySelectorAll('td'));
  const totalCells = cells.length;
  const cellsToColor = 14;

  const colorCounts = {
    green: 2,
    blue: 3,
    orange: 4,
    red: 5,
    black: blackColorApplied ? 0 : 1
  };

  const shuffledIndexes = getRandomIndexes(cellsToColor, totalCells);

  cells.forEach(cell => {
    cell.classList.remove('green', 'blue', 'orange', 'red', 'black');
    const messageDiv = cell.querySelector('.message');
    if (messageDiv) {
      messageDiv.remove();
    }
  });

  let index = 0;
  Object.entries(colorCounts).forEach(([color, count]) => {
    for (let i = 0; i < count; i++) {
      if (index >= shuffledIndexes.length) return;
      const cell = cells[shuffledIndexes[index++]];
      cell.classList.add(color);

      let currentValue = parseInt(cell.dataset.value, 10);
      let newValue;

      switch (color) {
        case 'green':
          newValue = currentValue + 3;
          showMessage(cell, '+3');
          break;
        case 'blue':
          newValue = currentValue + 2;
          showMessage(cell, '+2');
          break;
        case 'orange':
          newValue = currentValue + 1;
          showMessage(cell, '+1');
          break;
        case 'red':
          newValue = 0;
          if (!cell.querySelector('.message[data-message="zero"]')) {
            showMessage(cell, 'Você zerou!', 'zero');
          }
          removeNumberFromSelection(cell);
          break;
        case 'black':
          newValue = currentValue + 10;
          showMessage(cell, '+10');
          blackColorApplied = true;
          break;
      }

      cell.querySelector('.corner-value').textContent = newValue;
      cell.dataset.value = newValue;
    }
  });
}

function showMessage(cell, message, dataMessage) {
  const messageDiv = document.createElement('div');
  messageDiv.className = 'message';
  messageDiv.textContent = message;
  if (dataMessage) {
    messageDiv.dataset.message = dataMessage;
  }
  cell.appendChild(messageDiv);
}

function removeNumberFromSelection(cell) {
  const number = cell.dataset.number;
  selectedNumbers = selectedNumbers.filter(n => n !== number);
  document.querySelector(`td[data-number="${number}"]`)?.classList.remove('selected');
  updateSelectedNumbers();

  setTimeout(() => {
    if (!checkIfNumbersRemain()) {
      document.getElementById('round-counter').textContent = 'Jogo encerrado! Nenhum número restante.';
      determineWinner();
    }
  }, 5000); // Atraso de 5 segundos
}

function checkIfNumbersRemain() {
  const cells = Array.from(document.querySelectorAll('td'));
  return cells.some(cell => selectedNumbers.includes(cell.dataset.number));
}

function updateRoundCounter() {
  document.getElementById('round-counter').textContent = `Rodada: ${currentRound}`;
}

function startRounds() {
  document.getElementById('start-button').style.display = 'none';
  document.querySelector('table').style.display = 'table';
  document.getElementById('round-counter').style.display = 'block';

  const roundInterval = setInterval(() => {
    if (currentRound <= 10) {
      applyColors();
      updateRoundCounter();

      if (!checkIfNumbersRemain()) {
        clearInterval(roundInterval);
        document.getElementById('round-counter').textContent = 'Jogo encerrado! Nenhum número restante.';
        determineWinner();
      } else {
        currentRound++;
      }
    } else {
      clearInterval(roundInterval);
      document.getElementById('round-counter').textContent = 'Rodadas concluídas!';
      determineWinner();
    }
  }, 5000); // 5 segundos
}

function determineWinner() {
  const cells = Array.from(document.querySelectorAll('td'));
  let highestValue = -1;
  let winnerNumber = null;

  cells.forEach(cell => {
    if (selectedNumbers.includes(cell.dataset.number)) {
      const value = parseInt(cell.dataset.value, 10);
      if (value > highestValue) {
        highestValue = value;
        winnerNumber = cell.dataset.number;
      }
    }
  });

  if (highestValue > -1) {
    const result = `O vencedor é o número ${winnerNumber} com o valor ${highestValue}`;
    alert(result);
    generateQRCode(result);
  } else {
    alert('Nenhum número selecionado foi o vencedor.');
  }
}

function generateQRCode(data) {
  const existingQRCode = document.getElementById('qr-code-container');
  if (existingQRCode) {
    existingQRCode.remove();
  }

  const qrCodeImg = document.createElement('img');
  qrCodeImg.src = `https://api.qrserver.com/v1/create-qr-code/?size=150x150&data=${encodeURIComponent(data)}`;
  qrCodeImg.alt = 'QR Code';

  const qrCodeContainer = document.createElement('div');
  qrCodeContainer.id = 'qr-code-container';
  qrCodeContainer.style.textAlign = 'center';
  qrCodeContainer.style.marginTop = '20px';
  qrCodeContainer.appendChild(qrCodeImg);

  document.body.appendChild(qrCodeContainer);
}

function updateSelectedNumbers() {
  const selectedList = document.getElementById('selected-list');
  selectedList.textContent = selectedNumbers.length > 0 ? selectedNumbers.join(', ') : 'Nenhum';
}

document.querySelector('tbody').addEventListener('click', (event) => {
      if (event.target.tagName === 'TD') {
        const cell = event.target;
        const number = cell.dataset.number;

        if (cell.classList.contains('selected')) {
          cell.classList.remove('selected');
          selectedNumbers = selectedNumbers.filter(n => n !== number);
            } else {
                cell.classList.add('selected');
                selectedNumbers.push(number);
            }
            updateSelectedNumbers();
        }
    });

    document.getElementById('start-button').addEventListener('click', startRounds);
});